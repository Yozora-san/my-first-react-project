function ExpenseItem() {
  return (
    <div>
      <div></div>
      <h2></h2>
      <div></div>
    </div>
  );
}

export default ExpenseItem;
